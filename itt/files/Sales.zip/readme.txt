Sub SalesSummary_Full()
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim dictProduct As Object, dictCustomer As Object, dictState As Object
    Dim r As Long, prod As String, cust As String, st As String
    Dim amt As Double
    
    ' Set worksheet
    Set ws = ActiveSheet
    lastRow = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row
    
    ' Create dictionaries
    Set dictProduct = CreateObject("Scripting.Dictionary")
    Set dictCustomer = CreateObject("Scripting.Dictionary")
    Set dictState = CreateObject("Scripting.Dictionary")
    
    ' Loop through data rows
    For r = 2 To lastRow
        prod = Trim(ws.Cells(r, "D").Value)     ' Product in column D
        cust = Trim(ws.Cells(r, "C").Value)     ' Customer in column C
        st = Trim(ws.Cells(r, "H").Value)       ' State in column H
        
        If IsNumeric(ws.Cells(r, "G").Value) Then
            amt = ws.Cells(r, "G").Value        ' Amount in column G
        Else
            amt = 0
        End If
        
        ' Product-wise
        If prod <> "" Then
            If dictProduct.Exists(prod) Then
                dictProduct(prod) = dictProduct(prod) + amt
            Else
                dictProduct.Add prod, amt
            End If
        End If
        
        ' Customer-wise
        If cust <> "" Then
            If dictCustomer.Exists(cust) Then
                dictCustomer(cust) = dictCustomer(cust) + amt
            Else
                dictCustomer.Add cust, amt
            End If
        End If
        
        ' State-wise
        If st <> "" Then
            If dictState.Exists(st) Then
                dictState(st) = dictState(st) + amt
            Else
                dictState.Add st, amt
            End If
        End If
    Next r
    
    ' Clear old summary if any
    ws.Range("J:O").Clear
    
    ' Write headers
    ws.Range("J1").Value = "Product"
    ws.Range("K1").Value = "Product Sales (₹)"
    ws.Range("M1").Value = "Customer"
    ws.Range("N1").Value = "Customer Sales (₹)"
    ws.Range("P1").Value = "State"
    ws.Range("Q1").Value = "State Sales (₹)"
    
    Dim i As Long, key As Variant
    
    ' Output product summary
    i = 2
    For Each key In dictProduct.Keys
        ws.Cells(i, "J").Value = key
        ws.Cells(i, "K").Value = dictProduct(key)
        i = i + 1
    Next key
    
    ' Output customer summary
    i = 2
    For Each key In dictCustomer.Keys
        ws.Cells(i, "M").Value = key
        ws.Cells(i, "N").Value = dictCustomer(key)
        i = i + 1
    Next key
    
    ' Output state summary
    i = 2
    For Each key In dictState.Keys
        ws.Cells(i, "P").Value = key
        ws.Cells(i, "Q").Value = dictState(key)
        i = i + 1
    Next key
    
    ' Optional: Format output
    ws.Columns("J:Q").AutoFit
    
    MsgBox "Summary completed successfully!" & vbCrLf & _
           dictProduct.Count & " products, " & dictCustomer.Count & _
           " customers, " & dictState.Count & " states summarized.", vbInformation
End Sub
